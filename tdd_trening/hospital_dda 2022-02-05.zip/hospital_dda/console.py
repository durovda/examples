class Console:
    @staticmethod
    def input(question):
        return input(question)

    @staticmethod
    def print(message):
        print(message)
