def assert_lists_equal(actual_list, expected_list):
    assert actual_list == expected_list, f'\nactual   = {actual_list}' \
                                         f'\nexpected = {expected_list}'
