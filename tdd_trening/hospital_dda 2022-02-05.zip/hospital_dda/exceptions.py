class PatientIdNotIntegerError(Exception):
    pass


class MinStatusCannotDownError(Exception):
    pass


class PatientNotExistsError(Exception):
    pass
